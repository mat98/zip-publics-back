# payfast-cardfast98x
Projeto criado a partir do curso de nodejs da Alura, esse repositório foi baseado no curso do ano de 2020
<br>
## Tecnologias 👨‍💻
1. nodejs - framework back <br>
2. memcached - memória em cachê <br>
3. winston - logger de erro <br>
## Objetivos 🎯
1. Buscar mais funcionalidades de integração com a API dos correios, utilizando SOAP
