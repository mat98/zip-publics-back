import jwt from 'jsonwebtoken'

export default class LoginController{
    async Login(req,res) {
        const { email, password } = req.body

        try {
            
        } catch(error) {

        }
    }
}